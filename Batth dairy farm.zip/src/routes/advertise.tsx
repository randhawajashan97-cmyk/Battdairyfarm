import { createFileRoute } from "@tanstack/react-router";
import { useState, type FormEvent } from "react";
import { Field, FormStatus, PageHero, validate } from "@/components/site";

export const Route = createFileRoute("/advertise")({
  head: () => ({
    meta: [
      { title: "Advertise With Us — Batth Dairy Farm" },
      { name: "description", content: "Promote your feed, veterinary or agri business to dairy farmers and livestock buyers." },
      { property: "og:title", content: "Advertise With Us — Batth Dairy Farm" },
      { property: "og:description", content: "Promote your business to dairy farmers and livestock buyers." },
    ],
  }),
  component: Advertise,
});

function Advertise() {
  const [status, setStatus] = useState<{ ok: boolean; msg: string } | null>(null);
  const submit = (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const err = validate(new FormData(e.currentTarget), ["business", "person", "phone", "adType", "placement", "duration"]);
    if (err) return setStatus({ ok: false, msg: err });
    setStatus({ ok: true, msg: "Thanks! Your advertising inquiry was received. We'll be in touch soon." });
    e.currentTarget.reset();
  };
  return (
    <>
      <PageHero title="Advertise With Us" sub="Reach farmers, buyers and dairy customers. Promote Your Business on our homepage and category pages." />
      <section className="mx-auto max-w-7xl px-4 py-10">
        <div className="grid gap-6 md:grid-cols-3">
          {[["Homepage banner", "Top visibility for every visitor."], ["Livestock page", "Reach active buyers and sellers."], ["Products page", "Reach dairy shoppers."]].map(([t, d]) => (
            <div key={t} className="rounded-2xl border-2 border-dashed border-accent bg-cream p-6"><h2 className="text-xl font-bold">{t}</h2><p className="mt-1 text-muted-foreground">{d}</p></div>
          ))}
        </div>
      </section>
      <section className="mx-auto max-w-3xl px-4 py-6">
        <h2 className="text-3xl font-bold">Advertisement inquiry</h2>
        <form onSubmit={submit} noValidate className="mt-6 grid gap-4 rounded-2xl border bg-card p-6 sm:grid-cols-2">
          <Field label="Business name *"><input name="business" className="field" maxLength={100} /></Field>
          <Field label="Contact person *"><input name="person" className="field" maxLength={100} /></Field>
          <Field label="Phone *"><input name="phone" type="tel" className="field" /></Field>
          <Field label="Email"><input name="email" type="email" className="field" /></Field>
          <Field label="Ad type *"><select name="adType" className="field" defaultValue=""><option value="" disabled>Select</option><option>Banner</option><option>Featured listing</option><option>Sponsored product</option></select></Field>
          <Field label="Preferred placement *"><select name="placement" className="field" defaultValue=""><option value="" disabled>Select</option><option>Homepage</option><option>Livestock page</option><option>Products page</option></select></Field>
          <Field label="Duration *"><select name="duration" className="field" defaultValue=""><option value="" disabled>Select</option><option>1 week</option><option>1 month</option><option>3 months</option><option>6 months</option></select></Field>
          <div className="sm:col-span-2"><Field label="Message"><textarea name="message" rows={4} className="field" maxLength={1000} /></Field></div>
          <div className="space-y-3 sm:col-span-2"><FormStatus status={status} /><button className="btn btn-accent w-full">Promote Your Business</button></div>
        </form>
      </section>
    </>
  );
}
