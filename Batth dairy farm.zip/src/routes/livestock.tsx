import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState, type FormEvent } from "react";
import { AdSlot, Field, FormStatus, PageHero, validate } from "@/components/site";
import { ListingCard } from "@/components/listing-card";
import { LISTINGS } from "@/lib/data";

export const Route = createFileRoute("/livestock")({
  head: () => ({
    meta: [
      { title: "Buy & Sell Cows and Buffaloes — Batth Dairy Farm" },
      { name: "description", content: "Browse cows and buffaloes for sale with breed, age, milk yield and vaccination details, or post your own listing." },
      { property: "og:title", content: "Buy & Sell Cows and Buffaloes — Batth Dairy Farm" },
      { property: "og:description", content: "Livestock marketplace with filters and admin-verified listings." },
    ],
  }),
  component: Livestock,
});

const TABS = ["All", "Cows for Sale", "Buffaloes for Sale", "Buy Cows", "Buy Buffaloes", "Sell a Cow", "Sell a Buffalo"] as const;

function Livestock() {
  const [tab, setTab] = useState<(typeof TABS)[number]>("All");
  const [f, setF] = useState({ type: "", breed: "", maxPrice: "", location: "", minMilk: "", available: false });
  const [sellType, setSellType] = useState("Cow");
  const [status, setStatus] = useState<{ ok: boolean; msg: string } | null>(null);

  const pick = (t: (typeof TABS)[number]) => {
    setTab(t);
    if (t.startsWith("Sell")) { setSellType(t.includes("Cow") ? "Cow" : "Buffalo"); document.getElementById("post")?.scrollIntoView({ behavior: "smooth" }); return; }
    setF((p) => ({ ...p, type: t.includes("Cow") ? "Cow" : t.includes("Buffalo") ? "Buffalo" : "" }));
  };

  const list = useMemo(() => LISTINGS.filter((l) =>
    (!f.type || l.type === f.type) &&
    (!f.breed || l.breed.toLowerCase().includes(f.breed.toLowerCase())) &&
    (!f.maxPrice || l.price <= Number(f.maxPrice)) &&
    (!f.location || l.location.toLowerCase().includes(f.location.toLowerCase())) &&
    (!f.minMilk || l.milk >= Number(f.minMilk)) &&
    (!f.available || l.available)), [f]);

  const submit = (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const err = validate(new FormData(e.currentTarget), ["type", "breed", "age", "price", "location", "name", "phone"]);
    if (err) return setStatus({ ok: false, msg: err });
    setStatus({ ok: true, msg: "Thank you! Your listing was received and will appear once our team reviews it." });
    e.currentTarget.reset();
  };

  return (
    <>
      <PageHero title="Buy & Sell Livestock" sub="Cows and buffaloes with clear details. Listings show a Verified badge only after our team reviews them.">
        <div className="mt-6 flex flex-wrap gap-2">
          {TABS.map((t) => (
            <button key={t} onClick={() => pick(t)} className={`rounded-full border px-4 py-2 text-sm font-bold ${tab === t ? "bg-primary text-primary-foreground" : "bg-card"}`}>{t}</button>
          ))}
        </div>
      </PageHero>

      <section className="mx-auto grid max-w-7xl gap-8 px-4 py-10 lg:grid-cols-[260px_1fr]">
        <aside className="h-fit space-y-4 rounded-2xl border bg-card p-5">
          <h2 className="text-xl font-bold">Filters</h2>
          <Field label="Animal type"><select className="field" value={f.type} onChange={(e) => setF({ ...f, type: e.target.value })}><option value="">All</option><option>Cow</option><option>Buffalo</option></select></Field>
          <Field label="Breed"><input className="field" value={f.breed} onChange={(e) => setF({ ...f, breed: e.target.value })} placeholder="e.g. Murrah" /></Field>
          <Field label="Max price (₹)"><input className="field" type="number" value={f.maxPrice} onChange={(e) => setF({ ...f, maxPrice: e.target.value })} /></Field>
          <Field label="Location"><input className="field" value={f.location} onChange={(e) => setF({ ...f, location: e.target.value })} /></Field>
          <Field label="Min milk yield (L/day)"><input className="field" type="number" value={f.minMilk} onChange={(e) => setF({ ...f, minMilk: e.target.value })} /></Field>
          <label className="flex items-center gap-2 text-sm font-semibold"><input type="checkbox" checked={f.available} onChange={(e) => setF({ ...f, available: e.target.checked })} /> Available only</label>
        </aside>
        <div>
          <p className="mb-4 text-sm text-muted-foreground">{list.length} listings · sample data</p>
          <div className="grid gap-6 sm:grid-cols-2 xl:grid-cols-3">{list.map((l) => <ListingCard key={l.id} l={l} />)}</div>
          {!list.length && <p className="rounded-xl bg-muted p-8 text-center">No animals match these filters.</p>}
        </div>
      </section>

      <AdSlot placement="Livestock page" />

      <section id="post" className="mx-auto max-w-3xl scroll-mt-24 px-4 py-10">
        <h2 className="text-3xl font-bold">Post a Listing</h2>
        <p className="mt-2 text-muted-foreground">Sell a cow or buffalo. Fields marked * are required.</p>
        <form onSubmit={submit} className="mt-6 grid gap-4 rounded-2xl border bg-card p-6 sm:grid-cols-2" noValidate>
          <Field label="Animal type *"><select name="type" className="field" value={sellType} onChange={(e) => setSellType(e.target.value)}><option>Cow</option><option>Buffalo</option></select></Field>
          <Field label="Breed *"><input name="breed" className="field" maxLength={60} /></Field>
          <Field label="Age (years) *"><input name="age" type="number" min={0} className="field" /></Field>
          <Field label="Milk yield (L/day)"><input name="milk" type="number" min={0} className="field" /></Field>
          <Field label="Price (₹) *"><input name="price" type="number" min={0} className="field" /></Field>
          <Field label="Location *"><input name="location" className="field" maxLength={80} /></Field>
          <div className="sm:col-span-2"><Field label="Health / vaccination details"><textarea name="health" rows={2} className="field" maxLength={500} /></Field></div>
          <div className="sm:col-span-2"><Field label="Photos"><input name="photos" type="file" accept="image/*" multiple className="field" /></Field></div>
          <Field label="Your name *"><input name="name" className="field" maxLength={80} /></Field>
          <Field label="Phone *"><input name="phone" type="tel" className="field" /></Field>
          <div className="space-y-3 sm:col-span-2"><FormStatus status={status} /><button className="btn btn-primary w-full">Submit listing for review</button></div>
        </form>
      </section>
    </>
  );
}
