import { createFileRoute } from "@tanstack/react-router";
import cow from "@/assets/cow.jpg";
import { PageHero } from "@/components/site";

export const Route = createFileRoute("/about")({
  head: () => ({
    meta: [
      { title: "About Us — Batth Dairy Farm" },
      { name: "description", content: "Learn about Batth Dairy Farm, its livestock marketplace and fresh dairy products." },
      { property: "og:title", content: "About Batth Dairy Farm" },
      { property: "og:description", content: "Our story, our animals and our dairy." },
    ],
  }),
  component: About,
});

function About() {
  return (
    <>
      <PageHero title="About Batth Dairy Farm" sub="A place to find healthy animals and fresh dairy." />
      <section className="mx-auto grid max-w-7xl items-center gap-10 px-4 py-12 md:grid-cols-2">
        <img src={cow} alt="Healthy dairy cow on the farm" loading="lazy" width={944} height={704} className="rounded-2xl shadow-soft" />
        <div className="space-y-4 text-lg">
          <p>[Your farm's story — when it started, who runs it, and what you care about. Replace this placeholder text.]</p>
          <p>Batth Dairy Farm connects livestock buyers and sellers with clear, honest animal details, and offers fresh dairy products for local families.</p>
          <p className="text-muted-foreground">[Add any certifications or achievements here once confirmed.]</p>
        </div>
      </section>
    </>
  );
}
