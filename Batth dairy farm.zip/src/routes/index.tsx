import { createFileRoute, Link } from "@tanstack/react-router";
import hero from "@/assets/hero.jpg";
import dairy from "@/assets/dairy.jpg";
import { AdSlot } from "@/components/site";
import { LISTINGS, PRODUCT_CATEGORIES, CONTACT, telLink, waLink, inr } from "@/lib/data";
import { ListingCard } from "@/components/listing-card";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Batth Dairy Farm — Cows, Buffaloes & Fresh Dairy" },
      { name: "description", content: "Buy and sell cows and buffaloes, and order fresh milk, desi ghee, paneer and more from Batth Dairy Farm." },
      { property: "og:title", content: "Batth Dairy Farm — Cows, Buffaloes & Fresh Dairy" },
      { property: "og:description", content: "Livestock marketplace and fresh dairy products." },
    ],
  }),
  component: Index,
});

const REVIEWS = [
  { name: "Sample customer", text: "Found a healthy Murrah buffalo close to home. The details listed matched exactly." },
  { name: "Sample customer", text: "The ghee and dahi taste just like home-made. Delivery was on time." },
  { name: "Sample customer", text: "Listing my cow was simple and I got calls within days." },
];

function Index() {
  return (
    <>
      <section className="relative overflow-hidden">
        <img src={hero} alt="Cows and buffaloes grazing at a green dairy farm" width={1600} height={912} className="absolute inset-0 h-full w-full object-cover" />
        <div className="absolute inset-0 bg-hero-overlay" />
        <div className="relative mx-auto max-w-7xl px-4 py-24 text-primary-foreground md:py-36">
          <p className="font-bold uppercase tracking-widest text-accent">Batth Dairy Farm</p>
          <h1 className="mt-3 max-w-2xl text-4xl font-bold leading-tight md:text-6xl">Healthy livestock. Pure dairy. One trusted place.</h1>
          <p className="mt-4 max-w-xl text-lg opacity-90">Buy or sell cows and buffaloes, and order fresh milk, ghee, paneer and more straight from the farm.</p>
          <div className="mt-8 flex flex-wrap gap-3">
            <Link to="/livestock" className="btn btn-accent">Browse Livestock</Link>
            <Link to="/livestock" hash="post" className="btn btn-outline">List an Animal</Link>
            <Link to="/products" className="btn btn-outline">Shop Dairy Products</Link>
          </div>
        </div>
      </section>

      <section className="border-b bg-cream">
        <div className="mx-auto flex max-w-7xl flex-wrap items-center justify-between gap-3 px-4 py-4">
          <p className="font-semibold">Questions? Call {CONTACT.phone}</p>
          <div className="flex gap-2"><a href={waLink} className="btn btn-whatsapp">WhatsApp</a><a href={telLink} className="btn btn-primary">Call</a></div>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-4 py-16">
        <div className="flex items-end justify-between gap-4">
          <h2 className="text-3xl font-bold">Featured listings</h2>
          <Link to="/livestock" className="font-bold text-primary">View all →</Link>
        </div>
        <div className="mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {LISTINGS.filter((l) => l.verified && l.available).slice(0, 3).map((l) => <ListingCard key={l.id} l={l} />)}
        </div>
      </section>

      <AdSlot placement="Homepage banner" />

      <section className="bg-secondary">
        <div className="mx-auto grid max-w-7xl items-center gap-10 px-4 py-16 md:grid-cols-2">
          <img src={dairy} alt="Fresh milk, ghee, paneer, butter and curd" loading="lazy" width={1200} height={800} className="rounded-2xl shadow-soft" />
          <div>
            <h2 className="text-3xl font-bold">Popular dairy categories</h2>
            <div className="mt-6 grid grid-cols-2 gap-3">
              {PRODUCT_CATEGORIES.map((c) => (
                <Link key={c} to="/products" search={{ category: c }} className="rounded-xl bg-card p-4 font-bold shadow-soft hover:text-primary">{c}</Link>
              ))}
            </div>
            <p className="mt-4 text-sm text-muted-foreground">Fresh milk from {inr(60)}/litre (sample price).</p>
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-4 py-16">
        <h2 className="text-3xl font-bold">Why choose us</h2>
        <div className="mt-8 grid gap-6 md:grid-cols-4">
          {[["Admin-reviewed listings", "Verified badge only after our team reviews a listing."], ["Full animal details", "Breed, age, milk yield and vaccination info up front."], ["Fresh daily dairy", "Milk and products prepared fresh."], ["Direct contact", "Talk to sellers by phone or WhatsApp."]].map(([t, d]) => (
            <div key={t} className="rounded-2xl border bg-card p-6"><h3 className="text-lg font-bold text-primary">{t}</h3><p className="mt-2 text-muted-foreground">{d}</p></div>
          ))}
        </div>
      </section>

      <section className="bg-cream">
        <div className="mx-auto max-w-7xl px-4 py-16">
          <h2 className="text-3xl font-bold">What customers say</h2>
          <p className="text-sm text-muted-foreground">Sample reviews — replace with real customer feedback.</p>
          <div className="mt-8 grid gap-6 md:grid-cols-3">
            {REVIEWS.map((r, i) => (
              <figure key={i} className="rounded-2xl bg-card p-6 shadow-soft"><blockquote className="text-lg">“{r.text}”</blockquote><figcaption className="mt-4 font-bold text-primary">— {r.name}</figcaption></figure>
            ))}
          </div>
        </div>
      </section>
    </>
  );
}
