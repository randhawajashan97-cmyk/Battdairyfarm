import { createFileRoute, Link } from "@tanstack/react-router";
import { AdSlot, PageHero } from "@/components/site";
import { PRODUCTS, PRODUCT_CATEGORIES, inr, telLink, waLink } from "@/lib/data";

export const Route = createFileRoute("/products")({
  validateSearch: (s: Record<string, unknown>): { category?: string | undefined } => ({ category: typeof s["category"] === "string" ? (s["category"] as string) : undefined }),
  head: () => ({
    meta: [
      { title: "Fresh Dairy Products — Milk, Ghee, Paneer | Batth Dairy Farm" },
      { name: "description", content: "Order fresh milk, desi ghee, butter, curd, paneer and lassi from Batth Dairy Farm." },
      { property: "og:title", content: "Fresh Dairy Products — Batth Dairy Farm" },
      { property: "og:description", content: "Milk, desi ghee, butter, curd, paneer and lassi." },
    ],
  }),
  component: Products,
});

function Products() {
  const { category } = Route.useSearch();
  const list = PRODUCTS.filter((p) => !category || p.category === category);
  return (
    <>
      <PageHero title="Dairy Products" sub="Fresh from the farm. Prices shown are samples — call or WhatsApp to order.">
        <div className="mt-6 flex flex-wrap gap-2">
          <Link to="/products" search={{ category: undefined }} className={`rounded-full border px-4 py-2 text-sm font-bold ${!category ? "bg-primary text-primary-foreground" : "bg-card"}`}>All</Link>
          {PRODUCT_CATEGORIES.map((c) => (
            <Link key={c} to="/products" search={{ category: c }} className={`rounded-full border px-4 py-2 text-sm font-bold ${category === c ? "bg-primary text-primary-foreground" : "bg-card"}`}>{c}</Link>
          ))}
        </div>
      </PageHero>
      <section className="mx-auto grid max-w-7xl gap-6 px-4 py-10 sm:grid-cols-2 lg:grid-cols-3">
        {list.map((p) => (
          <article key={p.id} className="overflow-hidden rounded-2xl border bg-card shadow-soft">
            <img src={p.image} alt={p.name} loading="lazy" width={1200} height={800} className="aspect-[3/2] w-full object-cover" />
            <div className="p-5">
              <p className="text-xs font-bold uppercase tracking-wider text-muted-foreground">{p.category}</p>
              <div className="flex items-baseline justify-between gap-2"><h3 className="text-xl font-bold">{p.name}</h3><span className="font-extrabold text-primary">{inr(p.price)}</span></div>
              <p className="mt-1 text-muted-foreground">{p.description}</p>
              <p className="mt-3 text-sm"><b>Quantity:</b> {p.unit} · <b>{p.delivery}</b></p>
              <p className={`mt-1 text-sm font-bold ${p.available ? "text-primary" : "text-destructive"}`}>{p.available ? "In stock" : "Currently unavailable"}</p>
              <div className="mt-4 flex gap-2"><a href={waLink} className="btn btn-whatsapp flex-1 text-sm">Order on WhatsApp</a><a href={telLink} className="btn btn-primary flex-1 text-sm">Call</a></div>
            </div>
          </article>
        ))}
      </section>
      <AdSlot placement="Products page" />
    </>
  );
}
