import { createFileRoute } from "@tanstack/react-router";
import { useState, type FormEvent } from "react";
import { Field, FormStatus, PageHero, validate } from "@/components/site";
import { CONTACT, telLink, waLink } from "@/lib/data";

export const Route = createFileRoute("/contact")({
  head: () => ({
    meta: [
      { title: "Contact — Batth Dairy Farm" },
      { name: "description", content: "Call, WhatsApp or message Batth Dairy Farm about livestock or dairy orders." },
      { property: "og:title", content: "Contact Batth Dairy Farm" },
      { property: "og:description", content: "Get in touch about livestock or dairy orders." },
    ],
  }),
  component: Contact,
});

function Contact() {
  const [status, setStatus] = useState<{ ok: boolean; msg: string } | null>(null);
  const submit = (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const err = validate(new FormData(e.currentTarget), ["name", "phone", "message"]);
    if (err) return setStatus({ ok: false, msg: err });
    setStatus({ ok: true, msg: "Message received — we'll get back to you soon." });
    e.currentTarget.reset();
  };
  return (
    <>
      <PageHero title="Contact Us" sub="Questions about an animal or a dairy order? We're happy to help." />
      <section className="mx-auto grid max-w-7xl gap-10 px-4 py-12 md:grid-cols-2">
        <div className="space-y-3 text-lg">
          <p><b>Phone:</b> {CONTACT.phone}</p>
          <p><b>Email:</b> {CONTACT.email}</p>
          <p><b>Address:</b> {CONTACT.address}</p>
          <p><b>Hours:</b> {CONTACT.hours}</p>
          <div className="flex gap-3 pt-2"><a href={waLink} className="btn btn-whatsapp">WhatsApp</a><a href={telLink} className="btn btn-primary">Call now</a></div>
        </div>
        <form onSubmit={submit} noValidate className="space-y-4 rounded-2xl border bg-card p-6">
          <Field label="Name *"><input name="name" className="field" maxLength={100} /></Field>
          <Field label="Phone *"><input name="phone" type="tel" className="field" /></Field>
          <Field label="Email"><input name="email" type="email" className="field" /></Field>
          <Field label="Message *"><textarea name="message" rows={5} className="field" maxLength={1000} /></Field>
          <FormStatus status={status} />
          <button className="btn btn-primary w-full">Send message</button>
        </form>
      </section>
    </>
  );
}
