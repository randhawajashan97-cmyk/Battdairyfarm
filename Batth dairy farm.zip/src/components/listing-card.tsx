import { type Listing, inr, waLink } from "@/lib/data";

export function ListingCard({ l }: { l: Listing }) {
  return (
    <article className="overflow-hidden rounded-2xl border bg-card shadow-soft">
      <div className="relative">
        <img src={l.image} alt={`${l.breed} ${l.type.toLowerCase()}`} loading="lazy" width={944} height={704} className="aspect-[4/3] w-full object-cover" />
        {l.verified && <span className="absolute left-3 top-3 rounded-full bg-primary px-3 py-1 text-xs font-bold text-primary-foreground">✓ Verified</span>}
        {!l.available && <span className="absolute right-3 top-3 rounded-full bg-foreground px-3 py-1 text-xs font-bold text-background">Sold</span>}
      </div>
      <div className="p-5">
        <div className="flex items-baseline justify-between gap-2">
          <h3 className="text-xl font-bold">{l.breed} {l.type}</h3>
          <span className="text-lg font-extrabold text-primary">{inr(l.price)}</span>
        </div>
        <dl className="mt-3 grid grid-cols-2 gap-y-1 text-sm">
          <dt className="text-muted-foreground">Age</dt><dd>{l.age} yrs</dd>
          <dt className="text-muted-foreground">Milk yield</dt><dd>{l.milk} L/day</dd>
          <dt className="text-muted-foreground">Location</dt><dd>{l.location}</dd>
          <dt className="text-muted-foreground">Health</dt><dd>{l.health}</dd>
          <dt className="text-muted-foreground">Seller</dt><dd>{l.seller}</dd>
        </dl>
        <div className="mt-4 flex gap-2">
          <a href={`tel:${l.phone.replace(/\s/g, "")}`} className="btn btn-primary flex-1 text-sm">Call seller</a>
          <a href={waLink} className="btn btn-whatsapp flex-1 text-sm">WhatsApp</a>
        </div>
      </div>
    </article>
  );
}
