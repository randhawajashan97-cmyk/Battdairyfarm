import { Link } from "@tanstack/react-router";
import { useState, type ReactNode } from "react";
import { CONTACT, telLink, waLink } from "@/lib/data";

const NAV = [
  { to: "/", label: "Home" },
  { to: "/livestock", label: "Buy & Sell Livestock" },
  { to: "/products", label: "Dairy Products" },
  { to: "/advertise", label: "Advertise" },
  { to: "/about", label: "About Us" },
  { to: "/contact", label: "Contact" },
] as const;

export function Header() {
  const [open, setOpen] = useState(false);
  return (
    <header className="sticky top-0 z-40 border-b bg-background/95 backdrop-blur">
      <div className="mx-auto flex max-w-7xl items-center justify-between gap-4 px-4 py-3">
        <Link to="/" className="flex min-w-0 items-center gap-2">
          <span className="grid h-10 w-10 shrink-0 place-items-center rounded-full bg-primary font-display text-lg font-bold text-primary-foreground">B</span>
          <span className="truncate font-display text-xl font-bold text-primary">Batth Dairy Farm</span>
        </Link>
        <nav className="hidden gap-1 lg:flex">
          {NAV.map((n) => (
            <Link key={n.to} to={n.to} activeOptions={{ exact: n.to === "/" }} className="rounded-full px-3 py-2 text-sm font-semibold text-muted-foreground hover:text-primary" activeProps={{ className: "bg-secondary text-primary" }}>{n.label}</Link>
          ))}
        </nav>
        <a href={telLink} className="btn btn-primary hidden text-sm lg:inline-flex">Call now</a>
        <button aria-label="Menu" onClick={() => setOpen(!open)} className="rounded-md border px-3 py-2 text-sm font-semibold lg:hidden">{open ? "Close" : "Menu"}</button>
      </div>
      {open && (
        <nav className="flex flex-col border-t px-4 py-2 lg:hidden">
          {NAV.map((n) => (
            <Link key={n.to} to={n.to} onClick={() => setOpen(false)} className="py-3 font-semibold">{n.label}</Link>
          ))}
        </nav>
      )}
    </header>
  );
}

export function Footer() {
  return (
    <footer className="mt-20 bg-primary text-primary-foreground">
      <div className="mx-auto grid max-w-7xl gap-8 px-4 py-12 md:grid-cols-3">
        <div>
          <p className="font-display text-2xl font-bold">Batth Dairy Farm</p>
          <p className="mt-2 opacity-80">Livestock marketplace and fresh dairy products.</p>
        </div>
        <div className="space-y-1 opacity-90">
          <p className="font-bold">Contact</p>
          <p>{CONTACT.phone}</p><p>{CONTACT.email}</p><p>{CONTACT.address}</p>
        </div>
        <div className="flex flex-col gap-1 opacity-90">
          <p className="font-bold">Quick links</p>
          {NAV.slice(1).map((n) => <Link key={n.to} to={n.to} className="hover:underline">{n.label}</Link>)}
        </div>
      </div>
      <p className="border-t border-primary-foreground/20 py-4 text-center text-sm opacity-70">© {new Date().getFullYear()} Batth Dairy Farm</p>
    </footer>
  );
}

export function FloatingContact() {
  return (
    <div className="fixed bottom-4 right-4 z-50 flex flex-col gap-2">
      <a href={waLink} className="btn btn-whatsapp shadow-soft">WhatsApp</a>
      <a href={telLink} className="btn btn-primary shadow-soft">Call</a>
    </div>
  );
}

export function AdSlot({ placement }: { placement: string }) {
  return (
    <div className="mx-auto my-10 max-w-7xl px-4">
      <Link to="/advertise" className="flex flex-col items-center justify-center gap-1 rounded-xl border-2 border-dashed border-accent bg-cream px-4 py-8 text-center">
        <span className="text-xs font-bold uppercase tracking-widest text-accent-foreground/70">Advertisement · {placement}</span>
        <span className="font-display text-xl font-bold">Your business could be here</span>
        <span className="text-sm font-semibold text-primary">Promote Your Business →</span>
      </Link>
    </div>
  );
}

export function PageHero({ title, sub, children }: { title: string; sub: string; children?: ReactNode }) {
  return (
    <section className="bg-secondary">
      <div className="mx-auto max-w-7xl px-4 py-12 md:py-16">
        <h1 className="text-4xl font-bold text-primary md:text-5xl">{title}</h1>
        <p className="mt-3 max-w-2xl text-lg text-muted-foreground">{sub}</p>
        {children}
      </div>
    </section>
  );
}

export function FormStatus({ status }: { status: { ok: boolean; msg: string } | null }) {
  if (!status) return null;
  return <p role="status" className={`rounded-lg p-3 text-sm font-semibold ${status.ok ? "bg-secondary text-primary" : "bg-destructive/10 text-destructive"}`}>{status.msg}</p>;
}

export function Field({ label, children }: { label: string; children: ReactNode }) {
  return <label className="block text-sm font-semibold"><span className="mb-1 block">{label}</span>{children}</label>;
}

/** Simple validation: required fields + phone/email format. */
export function validate(data: FormData, required: string[]): string | null {
  for (const k of required) if (!String(data.get(k) ?? "").trim()) return "Please fill in all required fields.";
  for (const [k, v] of data.entries()) if (String(v).length > 1000) return `${k} is too long.`;
  const email = String(data.get("email") ?? "").trim();
  if (email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return "Please enter a valid email.";
  const phone = String(data.get("phone") ?? "").trim();
  if (phone && !/^[+\d\s-]{7,16}$/.test(phone)) return "Please enter a valid phone number.";
  return null;
}
