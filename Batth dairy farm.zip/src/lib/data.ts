import cow from "@/assets/cow.jpg";
import buffalo from "@/assets/buffalo.jpg";
import dairy from "@/assets/dairy.jpg";

// Editable placeholders — replace with Batth Dairy Farm's real details.
export const CONTACT = {
  phone: "+91 97790 43878",
  whatsapp: "919779043878", // digits only
  email: "info@yourdomain.com",
  address: "[Farm address — to be added]",
  hours: "[Opening hours — to be added]",
};
export const telLink = `tel:${CONTACT.phone.replace(/\s/g, "")}`;
export const waLink = CONTACT.whatsapp ? `https://wa.me/${CONTACT.whatsapp}` : "/contact";

export type Listing = {
  id: string; type: "Cow" | "Buffalo"; breed: string; age: number; milk: number;
  health: string; location: string; price: number; seller: string; phone: string;
  available: boolean; verified: boolean; image: string;
};

// Sample listings for demonstration only.
export const LISTINGS: Listing[] = [
  { id: "1", type: "Cow", breed: "Sahiwal", age: 4, milk: 14, health: "FMD & HS vaccinated", location: "Ludhiana", price: 85000, seller: "Sample Seller", phone: "+91 XXXXX XXXXX", available: true, verified: true, image: cow },
  { id: "2", type: "Buffalo", breed: "Murrah", age: 5, milk: 16, health: "FMD vaccinated, dewormed", location: "Bathinda", price: 120000, seller: "Sample Seller", phone: "+91 XXXXX XXXXX", available: true, verified: true, image: buffalo },
  { id: "3", type: "Cow", breed: "HF Cross", age: 3, milk: 22, health: "FMD vaccinated", location: "Moga", price: 95000, seller: "Sample Seller", phone: "+91 XXXXX XXXXX", available: true, verified: false, image: cow },
  { id: "4", type: "Buffalo", breed: "Nili-Ravi", age: 6, milk: 13, health: "HS vaccinated", location: "Amritsar", price: 98000, seller: "Sample Seller", phone: "+91 XXXXX XXXXX", available: false, verified: true, image: buffalo },
  { id: "5", type: "Cow", breed: "Gir", age: 5, milk: 12, health: "FMD & HS vaccinated", location: "Patiala", price: 75000, seller: "Sample Seller", phone: "+91 XXXXX XXXXX", available: true, verified: false, image: cow },
  { id: "6", type: "Buffalo", breed: "Murrah", age: 4, milk: 18, health: "Fully vaccinated", location: "Ludhiana", price: 140000, seller: "Sample Seller", phone: "+91 XXXXX XXXXX", available: true, verified: true, image: buffalo },
];

export const PRODUCT_CATEGORIES = ["Milk", "Desi Ghee", "Butter", "Curd & Yogurt", "Paneer", "Lassi & More"] as const;

export type Product = {
  id: string; name: string; category: (typeof PRODUCT_CATEGORIES)[number]; description: string;
  price: number; unit: string; available: boolean; delivery: string; image: string;
};

// Sample prices — edit to match the farm's actual offering.
export const PRODUCTS: Product[] = [
  { id: "p1", name: "Fresh Buffalo Milk", category: "Milk", description: "Full-cream milk collected every morning.", price: 70, unit: "1 litre", available: true, delivery: "Delivery & pickup", image: dairy },
  { id: "p2", name: "Fresh Cow Milk", category: "Milk", description: "Light, everyday cow milk.", price: 60, unit: "1 litre", available: true, delivery: "Delivery & pickup", image: dairy },
  { id: "p3", name: "Desi Ghee", category: "Desi Ghee", description: "Slow-cooked ghee with rich aroma.", price: 650, unit: "500 g", available: true, delivery: "Delivery & pickup", image: dairy },
  { id: "p4", name: "White Butter", category: "Butter", description: "Hand-churned unsalted makkhan.", price: 300, unit: "500 g", available: true, delivery: "Pickup only", image: dairy },
  { id: "p5", name: "Fresh Dahi", category: "Curd & Yogurt", description: "Thick, set curd made daily.", price: 80, unit: "1 kg", available: true, delivery: "Delivery & pickup", image: dairy },
  { id: "p6", name: "Soft Paneer", category: "Paneer", description: "Soft, fresh paneer made to order.", price: 180, unit: "500 g", available: false, delivery: "Pickup only", image: dairy },
  { id: "p7", name: "Sweet Lassi", category: "Lassi & More", description: "Chilled traditional lassi.", price: 40, unit: "500 ml", available: true, delivery: "Pickup only", image: dairy },
];

export const inr = (n: number) => "₹" + n.toLocaleString("en-IN");
